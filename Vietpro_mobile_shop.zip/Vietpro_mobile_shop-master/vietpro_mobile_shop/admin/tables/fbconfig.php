<?php

$fb = new Facebook\Facebook([
    'app_id' => 'xxxxxxxxxxxx', // Thay thông tin app của bạn vào đây
    'app_secret' => 'xxxxxxxxxxxxxx',
    'default_graph_version' => 'v3.0',
        ]);
?>

