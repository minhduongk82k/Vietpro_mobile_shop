<div id="footer-bottom">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12">
                <p>
                    2018 © Vietpro Academy. All rights reserved. Developed by Vietpro Software.
                </p>
            </div>
        </div>
    </div>
</div>