<div id="search" class="col-lg-6 col-md-6 col-sm-12">
    <form class="form-inline" method="post" action="index.php?page_layout=search">
        <input name="keyword" class="form-control mt-3" type="search" placeholder="Tìm kiếm" aria-label="Search">
        <button class="btn btn-danger mt-3" type="submit">Tìm kiếm</button>
    </form>
</div>

<!-- action: khi submit form thì sẽ chuyển hướng đến đường dẫn chúng ta gắn vào  -->