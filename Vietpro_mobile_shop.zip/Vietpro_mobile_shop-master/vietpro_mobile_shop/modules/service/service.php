<div id="service" class="col-lg-3 col-md-6 col-sm-12">
    <h3>Dịch vụ</h3>
    <p>Bảo hành rơi vỡ, ngấm nước Care Diamond</p>
    <p>Bảo hành Care X60 rơi vỡ ngấm nước vẫn Đổi mới</p>
</div>