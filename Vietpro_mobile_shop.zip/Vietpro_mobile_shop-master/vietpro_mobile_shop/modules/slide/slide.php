<ul class="carousel-indicators">
    <li data-target="#slide" data-slide-to="0" class="active"></li>
    <li data-target="#slide" data-slide-to="1"></li>
    <li data-target="#slide" data-slide-to="2"></li>
    <li data-target="#slide" data-slide-to="3"></li>
    <li data-target="#slide" data-slide-to="4"></li>
    <li data-target="#slide" data-slide-to="5"></li>
</ul>